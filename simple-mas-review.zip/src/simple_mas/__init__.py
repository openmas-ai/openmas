"""SimpleMAS: A lightweight SDK for building Multi-Agent Systems."""

__version__ = "0.1.0"

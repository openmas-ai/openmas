#!/usr/bin/env python
"""Simple MCP (Model Context Protocol) example script.

This script provides a minimal example of using the Model Context Protocol.
"""

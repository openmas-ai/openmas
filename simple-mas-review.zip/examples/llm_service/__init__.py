"""Simple LLM service package using FastMCP."""

__version__ = "0.1.0"

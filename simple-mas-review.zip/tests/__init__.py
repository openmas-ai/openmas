"""Test package for SimpleMAS."""

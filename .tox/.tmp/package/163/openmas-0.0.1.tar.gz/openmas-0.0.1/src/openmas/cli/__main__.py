"""Entrypoint for running the CLI directly as a Python module."""
from openmas.cli.main import main

if __name__ == "__main__":
    main()
